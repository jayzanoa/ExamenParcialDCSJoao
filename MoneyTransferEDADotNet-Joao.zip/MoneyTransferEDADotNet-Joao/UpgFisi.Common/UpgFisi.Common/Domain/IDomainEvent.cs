﻿namespace UpgFisi.Common.Domain
{
    public interface IDomainEvent
    {
    }
}