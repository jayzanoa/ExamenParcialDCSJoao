﻿using System;

namespace UpgFisi.Common.Domain
{
    public interface IIdentity
    {
        Guid Id { get; }
    }
}