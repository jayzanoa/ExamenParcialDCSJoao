﻿namespace UpgFisi.Common.Domain
{
    public abstract class Entity
    {

    }
}