﻿using UpgFisi.Common.Domain;

namespace Transactions.Domain
{
    public class TransferStateId : Identity
    {
    }
}