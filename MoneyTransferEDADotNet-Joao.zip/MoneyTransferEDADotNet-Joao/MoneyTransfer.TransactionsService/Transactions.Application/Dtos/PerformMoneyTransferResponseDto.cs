﻿namespace Transactions.Application.Dtos
{
    public class PerformMoneyTransferResponseDto
    {        
        public string Response { get; set; }
    }
}