﻿namespace Accounts.Application
{
    public interface IAccountApplicationService
    {
    }
}