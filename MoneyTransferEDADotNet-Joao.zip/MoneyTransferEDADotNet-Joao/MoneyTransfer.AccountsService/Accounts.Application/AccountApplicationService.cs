﻿namespace Accounts.Application
{
    public class AccountApplicationService : IAccountApplicationService
    {

    }
}