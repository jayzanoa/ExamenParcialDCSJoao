﻿namespace Accounts.Domain
{
    public enum AccountType
    {
        SAVING = 1,
        CURRENT = 2
    }
}