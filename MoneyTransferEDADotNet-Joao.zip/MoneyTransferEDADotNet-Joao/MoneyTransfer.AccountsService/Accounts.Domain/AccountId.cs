﻿using UpgFisi.Common.Domain;

namespace Accounts.Domain
{
    public class AccountId : Identity
    {
    }
}