﻿using UpgFisi.Common.Domain;

namespace Accounts.Domain
{
    public class CustomerId : Identity
    {
    }
}