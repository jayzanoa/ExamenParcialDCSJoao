﻿using NServiceBus;

namespace Customers.Messages.Commands
{
    public class RegisterCustomerCommand : ICommand
    {
    }
}