﻿using NServiceBus;

namespace Customers.Messages.Events
{
    public class CustomerRegisteredEvent : IEvent
    {
    }
}