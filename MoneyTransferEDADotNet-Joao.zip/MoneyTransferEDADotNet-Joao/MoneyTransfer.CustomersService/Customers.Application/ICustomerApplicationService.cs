﻿namespace Customers.Application
{
    public interface ICustomerApplicationService
    {
    }
}