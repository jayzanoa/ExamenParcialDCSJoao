﻿namespace Customers.Application
{
    public class CustomerApplicationService : ICustomerApplicationService
    {

    }
}